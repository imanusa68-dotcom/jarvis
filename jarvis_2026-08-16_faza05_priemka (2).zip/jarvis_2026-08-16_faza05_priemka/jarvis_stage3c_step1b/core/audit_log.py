# core/audit_log.py
"""
Одна касса для журнала решений двери (шаг 32, фаза 0).

Зачем этот файл появился
------------------------
Журнал гейта — единственное место, где написано, что именно Джарвис сделал
и почему дверь это разрешила. Лежал он внутри папки проекта
(BASE/logs/gate-audit.jsonl), а папка проекта сменная: каждая распаковка
свежего zip — это новая пустая тетрадь, а прошлая остаётся в «Загрузках»
и никем не читается. Ключ и настройки уехали в дом на шагах 1 и 2 по той же
причине; журнал был последним, кто остался в сменной части.

Правила этого файла
-------------------
1. Касса НИКОГДА не ломает дело. Любая ошибка внутри — тишина и False:
   записка о решении не стоит того, чтобы из-за неё не выполнилось действие.
2. Путь считается ПРИ ВЫЗОВЕ, а не при импорте. Константа уровня модуля уже
   один раз стоила проекту бага: JARVIS_STATE_DIR, выставленный тестом после
   импорта, не действовал, и прогон писал в настоящий дом владельца
   (см. config/loader.py, SETTINGS_FILE).
3. Под прогоном тестов без JARVIS_STATE_DIR журнал не выключается, а
   перенаправляется во временную папку процесса. Выключить нельзя: тогда
   сторожа не увидят пропажу записей. Писать в настоящий дом — тоже нельзя:
   восемьдесят файлов тестов не должны засорять журнал владельца.
4. Ничего не печатает. Кассу зовёт дверь, а дверь зовут и из оффлайн-ядра,
   где печать запрещена (то же правило, что у core/action_log.py). Потери
   видно через lost_count() — его покажет doctor в фазе 0 (Р11).
5. Формат строки только дополняется, никогда не переписывается: schema_ver
   стоит в каждой строке с первого дня.
6. Значения параметров в журнал не попадают никогда — только имена ключей.
   Правило живёт в двери (core/gate._audit), касса его не ослабляет.

Почему не через core/safe_json
-----------------------------
safe_json хранит состояние: целый документ, атомарная замена, снимки .bak.
Журнал — не состояние, а свидетельство: его только дописывают, его нельзя
откатить, и копировать его целиком на каждую строку нельзя. Поэтому здесь
своя ротация по размеру, а дом всё равно берётся у safe_json.state_dir():
дверь к состоянию остаётся одна.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

# Версия формата строки. Читатели фазы 1 (чёрный ящик) обязаны пропускать
# незнакомую версию, а не падать на ней.
SCHEMA_VER = 1

DIR_NAME = "logs"
FILE_NAME = "gate-audit.jsonl"

# Потолок: текущий файл + GENERATIONS поколений. 8 МБ — примерно год работы
# при сотне решений в день. В фазе 1 (агенты, task_id, цепочка) пересчитать:
# одна задача агента — десятки решений, а потоков до трёх.
MAX_BYTES = 8 * 1024 * 1024
GENERATIONS = 3

_LOCK = threading.Lock()

_size = None       # размер текущего файла в байтах; None — ещё не смотрели
_size_path = None  # для какого пути посчитан _size (тест меняет дом на ходу)
_lost = 0          # сколько строк не удалось записать с момента запуска
_sandbox = None    # временная папка на процесс, только под прогоном тестов


# -- Пути -----------------------------------------------------------------

def _under_tests() -> bool:
    return "pytest" in sys.modules


def _sandbox_dir() -> Path:
    global _sandbox
    if _sandbox is None:
        _sandbox = Path(tempfile.mkdtemp(prefix="jv_audit_"))
    return _sandbox


def dir_path() -> Path:
    """Папка журналов. Дом — тот же, что у базы, настроек и памяти."""
    from core.safe_json import STATE_DIR_ENV, state_dir
    if not os.environ.get(STATE_DIR_ENV, "").strip() and _under_tests():
        return _sandbox_dir()
    return state_dir() / DIR_NAME


def path() -> Path:
    """Адрес журнала. Считается каждый раз — см. правило 2 в шапке."""
    return dir_path() / FILE_NAME


def lost_count() -> int:
    """Сколько записей потеряно. Не ноль — значит журнал неполон."""
    return _lost


def reset() -> None:
    """Забыть кэш размера и счётчик потерь. Нужно тестам и доктору."""
    global _size, _size_path, _lost
    with _LOCK:
        _size = None
        _size_path = None
        _lost = 0


# -- Запись ---------------------------------------------------------------

def _stamp(record: dict) -> dict:
    """Три поля принадлежат кассе: версия формата и два времени.

    ts — по часам машины, как было с первого дня: смысл поля не меняем, иначе
    сломается тот, кто его уже умеет читать. ts_utc добавлен рядом, потому
    что в вечном журнале нужна метка, которую можно сверить с чужими часами:
    расхождение часов машины с реальностью уже ловилось на шаге 24.
    """
    stamped = {
        "schema_ver": SCHEMA_VER,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "ts_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    for key, value in record.items():
        if key not in stamped:   # звонящий не переписывает поля кассы
            stamped[key] = value
    return stamped


def _known_size(target: Path) -> int:
    """Размер текущего файла. stat() зовётся один раз на путь, а не на
    каждую строку: в фазе 1 строк будет много, и диск не должен оказаться
    на пути быстрого ответа."""
    global _size, _size_path
    key = str(target)
    if _size is None or _size_path != key:
        try:
            _size = target.stat().st_size
        except OSError:
            _size = 0
        _size_path = key
    return _size


def _rotate(target: Path) -> None:
    """gate-audit.jsonl -> .1 -> .2 -> .3; самое старое поколение выпадает.

    Переименование может не удаться: файл держит антивирус, облачная
    синхронизация или второй запуск. Тогда продолжаем писать в текущий
    файл, превысив потолок: журнал на девять мегабайт лучше, чем потерянная
    запись о том, что Джарвис удалил папку.
    """
    global _size
    for index in range(GENERATIONS, 1, -1):
        older = target.with_name(f"{target.name}.{index - 1}")
        if older.exists():
            try:
                os.replace(older, target.with_name(f"{target.name}.{index}"))
            except OSError:
                return
    try:
        os.replace(target, target.with_name(f"{target.name}.1"))
    except OSError:
        return
    _size = 0


def append(record: dict) -> bool:
    """Дописать одну строку. Возвращает False вместо исключения — всегда."""
    global _size, _lost
    try:
        line = json.dumps(_stamp(record), ensure_ascii=False) + "\n"
        weight = len(line.encode("utf-8"))
        with _LOCK:
            target = path()
            if _known_size(target) + weight > MAX_BYTES:
                _rotate(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            # newline="" — иначе на Windows Python подставит \r\n, и строки журнала
            # перестанут быть теми, что мы записали.
            with open(target, "a", encoding="utf-8", newline="") as handle:
                handle.write(line)
            _size = _known_size(target) + weight
        return True
    except Exception:
        with _LOCK:
            _lost += 1
        return False
